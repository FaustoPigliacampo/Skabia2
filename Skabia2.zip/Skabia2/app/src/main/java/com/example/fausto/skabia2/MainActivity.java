package com.example.fausto.skabia2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.SeekBar;
import android.view.View;


public class MainActivity extends AppCompatActivity {

    private TextView Text1;
    private TextView Text2;
    private TextView Text3;
    private TextView Text4;
    private TextView Text5;
    private TextView Text6;
    private Button Boton;
    private EditText Cantidad;
    private SeekBar Barra;
    private ImageView ImagenFernet;
    private ImageView ImagenCoca;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Text4 = (TextView)findViewById(R.id.Text4);
        Text5 = (TextView)findViewById(R.id.Text5);
        Text6 = (TextView)findViewById(R.id.Text6);
        Barra = (SeekBar)findViewById(R.id.Barra);
        Cantidad = (EditText)findViewById(R.id.Cantidad);
    }

    public void Calcular(View view){
        Integer PFernet = Barra.getProgress();
        Integer PCoca = 100-PFernet;
        Integer Vaso = Integer.parseInt(String.valueOf(Cantidad.getText()));
        Integer CFernet = (Vaso*PFernet)/100;
        Integer CCoca = (Vaso*PCoca)/100;
        Integer CBFernet = (Integer.parseInt(String.valueOf(CFernet/750)))+1;
        Integer CBCoca = (Integer.parseInt(String.valueOf(CCoca/2250)))+1;
        Integer PreFernet = 185;
        Integer PreCoca = 80;
        Text4.setText("Fernet (" + PFernet + "%)\n");
        Text4.setText(Text4.getText()+""+CFernet + "ml\n");
        Text5.setText("Coca (" + PCoca + "%)\n");
        Text5.setText(Text5.getText()+""+CCoca + "ml\n");
        Text4.setText(Text4.getText()+"Botellas (750ml) = " + CBFernet + " ($" + CBFernet*PreFernet + ")");
        Text5.setText(Text5.getText()+"Botellas (2250ml) = " + CBCoca + " ($" + CBCoca*PreCoca + ")");
        Text6.setText("Precio TOTAL: $" + ((CBFernet*PreFernet)+(CBCoca*PreCoca)));
    }

}
